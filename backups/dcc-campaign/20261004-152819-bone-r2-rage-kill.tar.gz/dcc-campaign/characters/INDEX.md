# characters index
Owner: see NAMING-CONVENTIONS.md | Updated: 2026-10-03


- characters/character-creation-5e.md: 5e character creation (intake) guide and sheet template. Owner: Syndicate. Status: draft v0.2.
- characters/_archive/character-creation-v0.1-superseded.md: retired v0.1 stub, history only. Owner: Syndicate. Status: retired.
- characters/hornn-wizard.md: Hornn's crawler (Wizard, Human, Merchant). Owner: AI GM. Status: draft, intake in progress.
- characters/moses-barbarian.md: Trailer Park Moses (John)'s crawler (Barbarian, Goliath, Artisan). Owner: AI GM. Status: draft, questionnaire complete; kit pending.
