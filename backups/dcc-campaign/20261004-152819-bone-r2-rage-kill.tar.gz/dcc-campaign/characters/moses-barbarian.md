# Moses's Crawler (Barbarian) — Bone Wifebeater
Owner: AI GM | Status: draft (intake sealed; registered in state) | Version: 0.4 | Updated: 2026-10-04
Summary: Trailer Park Moses (John)'s Floor 1 test crawler. Barbarian, Goliath (Artisan background). Questionnaire complete (incl. bonus1); kit SEALED ~2:00 CT — 112 spent / 13 credits left (steel Scale Mail). Handle locked Bone Wifebeater ~2:29 CT. Signature attack + Standing Orders locked ~2:34 CT; Standing Reactions locked ~2:35 CT (OAs on); registered in state ~2:38 CT.

## Identity
- Player: Trailer Park Moses (called John), Discord
- Crawler name: **Bone Wifebeater** (locked ~2:29 PM CT; 1d3 among Bone Wifebeater / Gut Sledge / Trailer Executer → 1)
- Look: built like Bane (Bane in a wifebeater); brawler, tank, explosive-expert vibe
- Signature attack name: **You Better Fucking Listen** (updated ~2:34 PM CT from You Better Listen)
- Standing Orders: When I say that line, go to the nearest thing we're fighting and hammer it until it's goo. (locked ~2:34 PM CT)
- Standing Reactions: Opportunity Attacks: on
- Class (provisional): Barbarian
- Background (Prior Employment): Artisan (smelter)
- Species (Latent Biology): Goliath (looks human until Floor 3). Quirk: "Big-boned, and the bones have opinions."

## Ability scores (rolled 4d6 drop lowest, three arrays, kept Set 3, total 70)
| STR | DEX | CON | INT | WIS | CHA |
|---|---|---|---|---|---|
| 15 (+2) | 13 (+1) | 12 (+1) | 9 (-1) | 9 (-1) | 12 (+1) |
Other arrays rolled and discarded: Set 1 (66), Set 2 (51). Source of truth for rolls: sessions/rolls-*.log and sessions/intake-progress.json.

## Starting kit
Cash on both (chosen ~1:41 PM CT): Barbarian gold option **75 GP** + Artisan gold option **50 GP** = **125 credits**.
Vending buyout restarted ~1:55 PM CT; **SEALED ~2:00 PM CT**:
- Spiked Sledgehammer (Maul) — 10
- Food Blocks (Rations) ×30 days — 15
- Scale Mail (steel) — 50 (AC 14 + Dex max 2; Stealth disadvantage)
- Rope (50 ft hempen) — 1
- Pencil & Paper (writing kit) — 1
- Reinforced Absorbing Gloves (Club) — 2
- Chain (10 ft) — 5
- Light Crossbow + 20 Bolts — 26
- Grappling Hook — 2
- Torches ×2 — ~0
**Total: 112 spent / 13 credits remaining.** Kit complete.


## Questionnaire / Fan Profile (complete)
- Q1, holding when the world ended: Sledgehammer
- Q2, last unnecessary purchase: Chewing tobacco
- Q3, harmless fear: Wasps
- Q4, what friends roast him for: Head of the trailer park association; drinks Natty Light
- Q5, smell/food/song that makes him happy: Rockin' the Beer Gut song
- Q6, fight plan: Hit them as many times as possible till they go down, and maybe continue hitting if they move
- Bonus1, hill you would die on: Dodge is better than Ford

## Level, HP, credits, achievements, inventory
Not tracked yet. Not yet registered in sessions/state.json; register with `state.py add-crawler` once name and kit are set.

## Notes
- Table settings: Costly Revives, Ludicrous comfort, Floor 1 Reprieve per intake.
- Opt-outs: none recorded.
