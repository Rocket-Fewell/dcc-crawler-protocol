# Decision 008: Crafting rules (follow-up to 004)
Owner: Syndicate | Status: final | Version: 1.0 | Updated: 2026-10-03
Summary: Syndicate's rules follow-up to decision 004: the crafting framework Caleb set in his brief, plus the Syndicate numbers (open to owner markup) in rules/20-crafting-5e.md.

- Follows: decisions/004-crafting-system.md (Syndicate leads crafting rules). Doesn't replace it.
- Applied in: rules/20-crafting-5e.md v0.2 (review; was v0.1.1 draft). Canon: CANON-LEDGER.md §10 (K-/X-C IDs).
- Set by Caleb (brief, 2026-10-03):
  - Crafting sits on 5e 2024 tool proficiencies plus workstations, and happens **only in a saferoom**. Explosives are inert in saferooms and stable only at the table.
  - Tables are Personal Space accessories. On Floors 1-3 they come only from loot, boxes or quests; saferoom shops sell them from Floor 4 (canon conflict X-C01 flagged; the DM may bend it). The first table drop is a story event.
  - Crafting skills (IED, Explosives Handling, Agent Provocateur) are homebrew boons, DM-granted.
  - Max two of each stat-buff potion per crawler; drinking during cooldown = Poisoned; failed infusion = Dud.
  - Mordecai's Special Brew keeps the core §6.5 mapping (5 rounds of regeneration, 10-hour lockout, max 2) and is **crafter-NPC-only**, as in core §6.5 (revised 2026-10-03: the crawler-brew allowance in rules v0.1 is removed). A crawler brewing it is only a possible far-future HOUSE unlock (canon hint: a level-9 Alchemy Table might remove the two-dose cap, ledger K-028).
- Numbers set by Syndicate (revisit after play; see the draft's §10): 2-hour shifts (1 per saferoom Long Rest); DCs 10/13/15/18/21 by rarity; bench supplies 10/50/500/5,000/25,000; table seniority +1 on odd floors plus coupons capped at 25,000 credits; table list price 25,000; explosive tiers Popper-Doomsday (2d6 to 16d6); potion cooldown 3 − Con modifier rounds (default ON, needs a core-rules merge); per-crafter floor caps (Uncommon 6 / Rare 3 / Very Rare 1).
- Pending Caleb: the draft's §10 open questions and §11 core-rules conflicts (potion cooldown, Personal Space pointer, Floor 1 goblin-workshop first-table option).
- Update 2026-10-03 (rules v0.1.1): Special Brew is crafter-NPC-only (core §6.5); added a Floor 1 goblin-workshop first-table owner-option (canon K-010, K-103, B1 ch17-19; default stays Floor 2, "no table before Floor 2" is HOUSE); GM recommendations (strict saferoom crafting, 1-round potion cooldown, Steady Hands ON for chat, keep four house stations, DM-granted boons) are recorded as pending owner decision (rules §10.1); economy numbers (coupon cap, list price) and explosive tiers (fireball-class damage vs level-3 parties) remain Caleb's decisions.
- Update 2026-10-03 (rules v0.2): Caleb approved the pending items in decisions/010-first-crafting-table.md, decisions/011-crafting-settings.md and decisions/012-crafting-economy-explosives.md. They are locked in rules/20-crafting-5e.md §10.1 and supersede the "Pending Caleb" items above (first-table option, potion cooldown, Steady Hands, house stations, boons, coupon cap and list price, Boomer cap). Potion cooldown is now 1 round (not 3 − Con); Special Brew keeps its own lockout.
