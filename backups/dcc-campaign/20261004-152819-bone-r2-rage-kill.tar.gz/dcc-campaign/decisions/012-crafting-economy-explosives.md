# Decision 012: Crafting Economy and Explosives
Owner: Borent Corp Systems Architect | Status: final | Version: 1.0 | Updated: 2026-10-03
Summary: Table price and coupon cap stay at 25,000; Boomer bomb capped at 6d6 until level 5.

- Approved by: Caleb, 2026-10-03 (approval 4 of 5).
- Basic table list price: 25,000 credits. Upgrade coupon cap: 25,000.
- Other draft prices stand as written in rules/20-crafting-5e.md (Crafting Studio, upgrade costs, bench supplies).
- Boomer bomb: capped at 6d6 until character level 5 (draft was 8d6 over 20 ft).
- Follow-up: Syndicate files crafting v0.2.
