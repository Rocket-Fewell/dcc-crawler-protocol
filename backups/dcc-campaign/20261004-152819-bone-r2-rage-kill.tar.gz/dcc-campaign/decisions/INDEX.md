# decisions index
Owner: see NAMING-CONVENTIONS.md | Updated: 2026-10-03

- 002-death-mode.md: Costly Revives, very costly and rare
- 003-death-bypasses.md: earned death bypasses
- 004-crafting-system.md: crafting added, owners
- 005-death-mode-tuning.md: Costly Revives numbers (follow-up to 002) and Special Brew mapping. Owner: Syndicate.
- 008-crafting-rules.md: crafting rules follow-up to 004 (Caleb framework + Syndicate numbers). Owner: Syndicate.
- 009-species-approach.md: species approach approved
- 010-first-crafting-table.md: Floor 2 drop, rare Floor 1, usable Floor 4
- 011-crafting-settings.md: crafting settings approved
- 012-crafting-economy-explosives.md: economy and Boomer cap
- 013-party-size.md: four players
