# Table Decisions
Owner: all bots (filed by Borent) | Updated: 2026-10-03
Numbers match files in decisions/ where a file exists.

- 001 Comfort level: Ludicrous (cursing, sexual crudity, bodily humor, your-mom jokes, cruelty, foot bit all OK). Private per-crawler opt-out. Decided by Caleb. (No file yet; recorded in gm-notes/00-gm-principles.md.)
- 002 Death Mode: Costly Revives, very costly and rare; canon-verified revives pre-approved. See decisions/002-death-mode.md.
- 003 Death bypasses: Cockroach-style save (VERIFIED) and potions are earned, DM-grantable boons; fatal-blow potion is a house rule; Half-Splat is falling-only (VERIFIED). See decisions/003-death-bypasses.md.
- 004 Crafting system added (alchemy, bombmaking, tables, ingredients). Syndicate leads rules, Lore researches canon, GM runs at table. See decisions/004-crafting-system.md.
- 005 Death Mode tuning (Syndicate): 1 revival per party per 3 floors, 3 per campaign, 1 per crawler; flat fees 5k/15k/40k/100k; two heavier cost picks; Revival Sickness; Special Brew canon mapping (max 2 per crawler). See decisions/005-death-mode-tuning.md.
- 006 Celestial boxes: max one per crawler for the whole campaign, finale or absurd feat only, GM discretion. (No file yet.)
- 007 Voice tags for GM output: [SYSTEM], [GM], [ROLL] (ROLL is never spoken). See bot/README.md. (No file yet.)
- 008 Crafting rules (Syndicate, follow-up to 004): saferoom-only crafting on 5e tool proficiencies; tables found/rewarded only on F1-3, shops from F4; crafting skills are DM-granted boons; 2 stat buffs per ability; Dud on failed infusion; Syndicate numbers open to markup. See decisions/008-crafting-rules.md and rules/20-crafting-5e.md. Version note: crafting file is v0.2 (decisions 010, 011, 012 applied as locked rules); Special Brew is crafter-NPC-only.
- 009 Species: nine 2024 SRD species at level 1; Floor 3 System offer of three (starting species + two DCC-style oddities) with one free rebuild. Approved by Caleb. See decisions/009-species-approach.md.
- 010 First crafting table: Floor 2 drop; very rare GM-triggered Floor 1 find; tables unusable until Floor 4 (carry/stash before). Approved by Caleb. See decisions/010-first-crafting-table.md.
- 011 Crafting settings: strict saferoom-only, 1-round potion cooldown, Steady Hands no-roll ON, four house stations marked HOUSE, crafting boons DM-granted only. Approved by Caleb. See decisions/011-crafting-settings.md.
- 012 Crafting economy and explosives: tables and coupon cap stay 25,000; Boomer bomb capped at 6d6 until level 5. Approved by Caleb. See decisions/012-crafting-economy-explosives.md.
- 013 Party size: 4 players. Roster (names, concepts) pending. See decisions/013-party-size.md.
