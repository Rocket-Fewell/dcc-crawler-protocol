# tables index
Owner: see NAMING-CONVENTIONS.md | Updated: 2026-10-03


- tables/achievements.csv and tables/achievements.xlsx: achievement catalog, 1,823 rows (data files). Owner: Syndicate. Status: draft. Header card: tables/achievements.md.
