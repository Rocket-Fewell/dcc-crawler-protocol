# Master Index
Owner: Borent Corp Systems Architect | Status: draft | Version: 0.1 | Updated: 2026-10-03
Summary: Every file in the campaign workspace, one line each.

| Path | Description | Owner | Status |
|---|---|---|---|
| NAMING-CONVENTIONS.md | Folder layout and file naming rules | Borent | final |
| lore/INDEX.md | Canon catalogs, sources and research tools | DCC Lore | living |
| lore/CANON-LEDGER.md | Verified/unverified canon findings with sources | DCC Lore | in progress |
| rules/_source-crawler-protocol/02-core-rules-5e.md | 5e (2024) overlay: loot boxes, death and revival | Syndicate | draft v0.2.2 |
| rules/_source-crawler-protocol/05-campaign-narrative.md | Story spine | Syndicate | draft |
| bot/README.md | Discord voice bridge: setup and tag contract | Borent | draft |
| decisions/002-death-mode.md | Death Mode decision: Costly Revives, very costly and rare | Borent | final |
| decisions/003-death-bypasses.md | Earned death bypasses vs revives | Borent | final |
| decisions/004-crafting-system.md | Crafting system added; ownership split | Borent | final |
| rules/10-core-rules-5e.md | 5e (2024) overlay: achievements, loot boxes, death/revival, Floor 1 quickstart | Syndicate | draft v0.2.5 |
| characters/character-creation-5e.md | 5e character creation (intake) guide and crawler sheet template | Syndicate | draft v0.2 |
| characters/hornn-wizard.md | Hornn crawler sheet (Wizard, Human, Merchant), intake in progress | AI GM | draft |
| characters/moses-barbarian.md | Trailer Park Moses (John) crawler sheet (Barbarian, Goliath, Artisan), intake in progress | AI GM | draft |
| floors/f01/00-overview.md | Floor 1 The Orientation Pit: full 5e module (zones, boss, announcements) | Syndicate | draft v0.2.1 |
| floors/00-campaign-narrative.md | Campaign spine: Continuum floor structure and story arc | Syndicate | draft v0.3 |
| tables/achievements.csv | Achievement catalog, 1,823 rows (data); card in tables/achievements.md | Syndicate | draft |
| tables/achievements.xlsx | Achievement catalog, same data with filters (data) | Syndicate | draft |
| decisions/005-death-mode-tuning.md | Costly Revives numbers (follow-up to 002) and Special Brew mapping | Syndicate | final |
| rules/_archive/core-rules-v0.1-superseded.md | Retired v0.1 core rules | Syndicate | retired |
| characters/_archive/character-creation-v0.1-superseded.md | Retired v0.1 character creation | Syndicate | retired |
| floors/f01/_archive/floor-01-v0.1-stub-superseded.md | Retired v0.1 Floor 1 stub | Syndicate | retired |
| rules/20-crafting-5e.md | Crafting rules: tables/levels, ingredients, recipes, potion limits, explosives, failure, quick reference | Syndicate | review v0.2 |
| rules/30-species-supplement-5e.md | Species supplement: Floor 3 Offer procedure, rebuild rules, 12 DCC-style oddities, balance table, open questions, source map | Syndicate | draft v0.1.2 |
| decisions/008-crafting-rules.md | Crafting rules decision (follow-up to 004): framework + Syndicate numbers | Syndicate | final |
| decisions/009-species-approach.md | Species approach: SRD nine plus Floor 3 offer | Borent | final |
| decisions/010-first-crafting-table.md | First crafting table location and use rules | Borent | final |
| decisions/011-crafting-settings.md | Approved crafting settings | Borent | final |
| decisions/012-crafting-economy-explosives.md | Crafting economy numbers and Boomer cap | Borent | final |
| decisions/013-party-size.md | Party size: four players | Borent | final |
| tools/INDEX.md | Index of the AI GM shell tools (roll.py, state.py) | Borent | draft |
| tools/README.md | How the AI GM rolls dice and edits live state: exact commands and examples | Borent | draft |
| tools/roll.py | Dice roller (kh/kl/dh/dl, adv/dis, crits); [ROLL] line + roll log | Borent | draft |
| tools/state.py | Live state manager for sessions/state.json (HP, inventory, credits, revive caps, backups) | Borent | draft |
| tools/tests/test_roll.py | Tests for roll.py | Borent | draft |
| tools/tests/test_state.py | Tests for state.py | Borent | draft |
| tools/gm_quirks.py | GM-only secret trait roll, degeneration level and Affinity commands (run via tools/state.py); secret files are intentionally not indexed | Borent | draft |
| tools/sim_floors.py | Planning-only Monte Carlo for the degeneration ladder and Affinity bands | Borent | draft |
| tools/tests/test_gm_quirks.py | Tests for gm_quirks.py and sim_floors.py | Borent | draft |
| tools/discord_gm.py | Discord bridge CLI for the GM (say/read/new) plus `stop` (voice kill switch, writes sessions/voice-control.json) and `spotlight set/clear/show` (writes sessions/spotlight.json; the bridge then wakes the GM only for that player or the wake word "AI") | Borent | draft |
| tools/tests/test_discord_gm.py | Tests for the discord_gm.py spotlight subcommand | Borent | draft |
