# rules index
Owner: see NAMING-CONVENTIONS.md | Updated: 2026-10-03


- rules/10-core-rules-5e.md: 5e (2024) overlay for the Crawl (achievements, loot boxes, death/revival, Floor 1 quickstart). Owner: Syndicate. Status: draft v0.2.4.
- rules/20-crafting-5e.md: crafting rules (tables, levels, ingredients, recipes, potion limits, explosives, failure, System snark, quick reference). Owner: Syndicate. Status: review v0.2 (approved by Caleb 2026-10-03 apart from open questions).
- rules/30-species-supplement-5e.md: species supplement (Floor 3 Offer of starting species + two oddities, free optional rebuild, 12 DCC-style oddities tagged CANON / CANON-INSPIRED / HOUSE, balance table, open questions, source map). Owner: Syndicate. Status: draft v0.1.2.
- rules/_archive/core-rules-v0.1-superseded.md: retired v0.1 core rules, history only. Owner: Syndicate. Status: retired.
- rules/_source-crawler-protocol/: link to the original Crawler Protocol folder (working source; originals of every copied file stay there).

**Path map** (cross-references inside the copied files use the source names): `02-core-rules-5e.md` = rules/10-core-rules-5e.md; `03-character-creation-5e.md` = characters/character-creation-5e.md; `floors/floor-01-5e.md` = floors/f01/00-overview.md; `05-campaign-narrative.md` = floors/00-campaign-narrative.md; `reference/achievements.csv|xlsx` = tables/achievements.csv|xlsx; `DECISION-death-mode.md` = decisions/005-death-mode-tuning.md.
