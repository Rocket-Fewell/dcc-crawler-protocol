# Hornn's Crawler (Wizard) - UNNAMED
Owner: AI GM | Status: draft (intake in progress) | Version: 0.1 | Updated: 2026-10-04
Summary: Hornn's Floor 1 test crawler. Wizard, Human (Merchant background). Kit and questionnaire still pending.

## Identity
- Player: Hornn (Discord)
- Crawler name: not chosen yet
- Look: Cad Bane with long hair, a mullet; cowboy-hippie-wizard-rocket-scientist vibe
- Class (provisional): Wizard
- Background (Prior Employment): Merchant (operations manager / full-time dad in real life)
- Species (Latent Biology): Human (looks human on Floors 1-2 regardless)

## Ability scores (rolled 4d6 drop lowest, three arrays, kept Set 1, total 84)
| STR | DEX | CON | INT | WIS | CHA |
|---|---|---|---|---|---|
| 12 (+1) | 12 (+1) | 15 (+2) | 17 (+3) | 13 (+1) | 15 (+2) |
Other arrays rolled and discarded: Set 2 (64), Set 3 (71). Source of truth for rolls: sessions/rolls-*.log and sessions/intake-progress.json.

## Starting kit
Pending (class kit or Merchant package or gold, not chosen yet).

## Questionnaire / Fan Profile
Pending (not started).

## Level, HP, credits, achievements, inventory
Not tracked yet. Not yet registered in sessions/state.json; register with `state.py add-crawler` once name and kit are set.

## Notes
- Table settings: Costly Revives, Ludicrous comfort, Floor 1 Reprieve per intake.
- Opt-outs: none recorded.
