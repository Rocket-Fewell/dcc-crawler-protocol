# Open Threads
Owner: DCC AI GM | Status: draft | Version: 0.1 | Updated: 2026-10-03
Summary: Things still waiting on a decision or on another bot.

- Death Mode: decided, Costly Revives (very costly and rare). Needs a decisions/ file and DECISIONS.md update (Borent/Syndicate).
- Player roster: names, classes, tone preferences (Caleb).
- Achievement remap guidelines from Caleb (incoming).
- Discord voice bridge: bot token, Application ID, OpenAI key, channel names (Caleb with Borent).
- Roll20 account and API access (optional, later).
- 5e character creation file and Floor 1 module (Syndicate, in progress).
- Canon ledger (DCC Lore, in progress).
- Read (2026-10-03): characters/character-creation-5e.md v0.2 and floors/f01/00-overview.md (Floor 1 module). Structure looks runnable: intake kiosk, 11 zones, boss Dean Thudd, stairwell summary.
- Crafting rules: Syndicate (lead), needs DCC Lore's crafting-canon.md first.
- APPROVED 2026-10-03 (Caleb) species: start with one of nine 2024 SRD species; Floor 3 System offers three choices (starting species + two DCC-style oddities), one free rebuild. Syndicate to write species supplement; Borent to file decision.
- Approval queue remaining: (2) first crafting table location, (3) crafting settings, (4) economy numbers + explosive damage, (5) player roster.
- APPROVED 2026-10-03 (Caleb) first table: default Floor 2 scripted drop; rare random chance (very low) a table is found on Floor 1; tables cannot be USED until Floor 4 either way (Caleb). Needs rules/20-crafting-5e.md update (Syndicate) and a decision file (Borent).
- APPROVED 2026-10-03 (Caleb) crafting settings: strict saferoom-only crafting, 1-round potion cooldown, Steady Hands no-roll mode on, four house stations kept (HOUSE), crafting boons DM-granted only.
- APPROVED 2026-10-03 (Caleb) economy/explosives: table price and coupon cap stay 25,000; Boomer capped at 6d6 until level 5.
- Remaining approval: (5) player roster (names, classes, tone, Death Mode already set).
- CONFIRMED 2026-10-03 (Caleb): 4 players. Floor 1 module is tuned for 4 crawlers. Need each player's name, concept, class, tone via intake.
- Tools (Borent, 2026-10-03): `python3 tools/roll.py "2d20kh1+5" --label X --who Y [--dc N]` prints [ROLL] line and logs to sessions/rolls-DATE.log. `python3 tools/state.py <cmd>` manages sessions/state.json (init, add-crawler, hp, credits, inventory, achievement, condition, box, use-bypass, use-revive, snapshot, validate, restore). Run from /workspace/dcc-campaign. Docs: tools/README.md. Death saves/unconscious: use `condition add`.

- 2026-10-04: GM persona filed by Borent at gm-notes/20-gm-persona.md. Caleb: no hard limits on the GM persona; per-crawler private opt-outs still apply. Merge note from me: keep GM as bar-owner/carnival-barker (not game-show host, which is the System).

- 2026-10-04 PACING (Caleb): GM was talking way too much on voice. Rule: 2-4 spoken sentences per reply, one beat, less exposition but not terse; end on a prompt; max one reply per wake; check recent posts via `read --limit 10` to avoid duplicate answers from parallel runs.
- 2026-10-04 ~1:07 PM CT (live intake): players locked party at **2** (Hornn = Provisional Wizard; Trailer Park Moses / John = Provisional Barbarian). Overturns earlier '4 players' confirmation for this table until someone un-locks it. Still need Prior Employment + Latent Biology (+ scores, kit, questionnaire).
- 2026-10-04 ~1:09 PM CT (live intake): Trailer Park Moses Latent Biology = **Goliath**. Still need Prior Employment for both + Latent Biology for Hornn (+ scores, kit, questionnaire).
- 2026-10-04 ~1:11 PM CT (live intake): Hornn Prior Employment = **Merchant** (Ops Manager / full-time dad); Latent Biology = **Human**. Still need Prior Employment for Trailer Park Moses (+ scores, kit, questionnaire).
- 2026-10-04 ~1:11 PM CT (live intake): Hornn Prior Employment = **Merchant** (Operations Manager / full-time dad); Latent Biology = **Human**. Moses said smelter (+ likes to eat); GM asked him to confirm **Artisan** or name another 2024 background. Next after that: scores / kit / questionnaire.
- 2026-10-04 ~1:12 PM CT (live intake): Trailer Park Moses Prior Employment = **Artisan** (smelter; confirmed closest). Both crawlers have class/background/species. Next: scores / kit / questionnaire.
- 2026-10-04 ~1:15 PM CT (live intake): Hornn = point buy; Moses = roll 4d6dl1 ×3 (keep >69). Sets: 66 / 51 / **70**. Moses assign Set 3; Hornn submit 27-pt scores. Then kit/questionnaire.
- 2026-10-04 ~1:18 PM CT (live intake): Hornn switched to roll-three (Sets 84/64/71; keep 1 or 3, INT/CHA/CON high). Moses assigning Set 3: STR/DEX high, CHA next; still needs CON/INT/WIS for 12/9/9. Then kit/questionnaire.
- 2026-10-04 ~1:19 PM CT (live intake): Hornn said "Roll." — skipped (arrays already posted). Canonical Hornn Sets remain 84/64/71 (parallel 69/70/75 discarded). Waiting: Hornn pick Set 1 or 3 + assign; Moses name CON/INT/WIS for 12/9/9. Then kit/questionnaire.
- 2026-10-04 ~1:21 PM CT (live intake): Hornn "Pretty much go the same." — skipped (incomplete; no set pick / six-score map). Moses "Todd/Jason" dumps already answered by parallel [GM] ask for CON/INT/WIS letters. Hornn later said picking Set 1 (84) in a following utterance — leave for that wake. Next: Hornn assign Set 1 (INT/CHA/CON high); Moses name CON/INT/WIS for 12/9/9. Then kit/questionnaire.
- 2026-10-04 ~1:21 PM CT (live intake): Moses said "Todd gets the twelve, Jason twin nines" (STT) — not valid CON/INT/WIS map; GM asked again. Hornn said picking Set 1 (84) — pending assign (parallel may stamp). Still need full six-score maps, then kit/questionnaire.
- 2026-10-04 ~1:21 PM CT (live intake): Hornn locked **Set 1 (84)**. Moses "Todd/Jason" dump assign rejected as non-stats; still needs CON/INT/WIS for 12/9/9. STT garble noted by Moses. Next: Hornn full six-score assign; Moses name CON/INT/WIS; then kit/questionnaire.
- 2026-10-04 ~1:22 PM CT (live intake): Hornn **Set 1 locked** (84: 17/15/15/13/12/12). Waiting: Hornn assign INT/CHA/CON on highs + STR/DEX/WIS on 13/12/12; Moses name CON/INT/WIS for leftover 12/9/9 (Todd/Jason STT rejected). Then kit/questionnaire.
- 2026-10-04 ~1:23 PM CT (live intake): Moses scores locked — STR15 DEX13 CON12 INT9 WIS9 CHA12 (Set 3). Waiting: Hornn Set 1 six-score assign; then kit/questionnaire.
- 2026-10-04 ~1:23 PM CT (live intake): Moses scores **locked** Set 3 — STR15 DEX13 CON12 INT9 WIS9 CHA12 (after Con twelve / Intelligence nine / Wisdom). Parallel run stamped Mouth. Next: Hornn assign Set 1 (INT/CHA/CON on highs, STR/DEX/WIS on 13/12/12); then kit/questionnaire for both.
- 2026-10-04 ~1:24 PM CT (live intake): Moses "すごい。" / Hornn "That's funny." (+ prior mic chatter) — skipped reply; player-to-player meta about STT/mics. Moses scores already locked (STR15 DEX13 CON12 INT9 WIS9 CHA12). Next: Hornn Set 1 six-score assign (INT/CHA/CON highs, then STR/DEX/WIS on 13/12/12); then kit/questionnaire.
- 2026-10-04 ~1:25 PM CT (live intake): Hornn partial leftovers logged — STR12 DEX12 WIS13 (Set 1). Still need INT/CHA/CON on 17/15/15. Moses scores locked. Then kit/questionnaire.
- 2026-10-04 ~1:26 PM CT (live intake): Moses "哈哈" + Hornn/Moses Discord-notification meta — skipped reply; STT/player chatter. Hornn still needs INT/CHA/CON on 17/15/15 (leftovers already STR12 DEX12 WIS13). Moses scores locked. Then kit/questionnaire.
- 2026-10-04 ~1:26 PM CT (live intake): Moses Thai/dobra + 哈哈 / Hornn notification meta — skipped reply; player-to-player STT/bridge chatter. Parallel Mouth already stamped Hornn leftovers STR12 DEX12 WIS13 and asked INT/CHA/CON on 17/15/15. Next: Hornn finish Set 1 highs; then kit/questionnaire.
- 2026-10-04 ~1:27 PM CT (live intake): Hornn scores **locked** Set 1 — STR12 DEX12 CON15 INT17 WIS13 CHA15 (Intel 17 / Charisma 15 / Con 15). Parallel Mouth already stamped + asked who goes first on kit/questionnaire. This wake skipped reply. Next: kit + questionnaire for both.
- 2026-10-04 ~1:28 PM CT (live intake): Hornn deferred kit/questionnaire to John (Trailer Park Moses). Posted [SYSTEM]/[GM] Moses first: class package or gold + Artisan package or gold. Then questionnaire; Hornn waits.

- 2026-10-04 ~1:28 PM CT (live intake): Hornn volunteered John first; Moses said okay for questionnaire. Posted Q1 for Trailer Park Moses (holding when world ended). Next: Moses Q1–Q6; then Hornn kit/questionnaire; kit pending both.
- 2026-10-04 ~1:30 PM CT (live intake): Moses Q1 = **Sledgehammer.** Next: Moses Q2–Q6; then Hornn kit/questionnaire; kit pending both.
- 2026-10-04 ~1:31 PM CT (live intake): Moses Q2 = **Chewing tobacco.** Next: Moses Q3–Q6; then Hornn kit/questionnaire; kit pending both.
- 2026-10-04 ~1:32 PM CT (live intake): Moses Q3 = **Wasps.** Next: Moses Q4–Q6; then Hornn kit/questionnaire; kit pending both.
- 2026-10-04 ~1:33 PM CT (live intake): Moses Q3 = **Wasps.** Parallel Mouth already posted Q4. Skipped duplicate. Next: Moses Q4–Q6; then Hornn kit/questionnaire; kit pending both.
- 2026-10-04 ~1:33 PM CT (live intake): Moses/Hornn STT language meta — skipped reply; Q4 already live. Next: Moses Q4–Q6; then Hornn kit/questionnaire; kit pending both.
- 2026-10-04 ~1:34 PM CT (live intake): Moses Q4 = **Head of the trailer park association; drinks Natty Light.** Next: Moses Q5–Q6; then Hornn kit/questionnaire; kit pending both.

- 2026-10-04 ~1:34 PM CT (live intake): Moses Q4 = **trailer park association head / Natty Light.** Parallel Mouth already asked Q5. This wake (Hello / awesome) skipped — not Q5. Next: Moses Q5–Q6; then Hornn kit/questionnaire; kit pending both.
- 2026-10-04 ~1:35 PM CT (live intake): Moses "Entschuldigung." / "啊" after Q5 already out. Skipped — STT language meta, not Q5. Next: Moses Q5–Q6; then Hornn kit/questionnaire; kit pending both.

- 2026-10-04 ~1:36 PM CT (live intake): Moses Q5 = **Rockin' the Beer Gut song.** Next: Moses Q6 (+ bonus); then Hornn kit/questionnaire; kit pending both.
- 2026-10-04 ~1:37 PM CT (live intake): Moses Q6 = **Hit them till they go down (keep hitting if they move).** Core six done. Bonus1 asked (hill you would die on). Then Moses kit; Hornn kit/questionnaire; kit pending both.
- 2026-10-04 ~1:39 PM CT (live intake): Moses bonus1 = **Dodge is better than Ford.** Questionnaire complete. Next: Moses kit (class package or gold + Artisan package or gold); then Hornn kit/questionnaire; kit pending both.

- 2026-10-04 SPOTLIGHT RULE (Caleb): while in dialogue with one player, ignore all other players. Implemented via sessions/focus.json read by the Discord routine. Currently focused on Trailer Park Moses (intake).
- 2026-10-04 ~1:39 PM CT (live intake): Moses Bonus1 = **Dodge is better than Ford.** Questionnaire done. Next: Moses kit (Barbarian package or gold + Artisan package or gold); then Hornn kit/questionnaire; kit pending both.
- 2026-10-04 ~1:45 PM CT (live intake): Moses vending checkout complete (**34** spent, **91** credits left). Next: Hornn kit (Wizard/Merchant package-or-gold) then Hornn questionnaire.

- 2026-10-04 EXCHANGE FRAMEWORK (Caleb): call out addressee, listen only to them, announce when finished, "AI" wake word breaks in. Built into the Discord routine prompt and gm-principles.
- 2026-10-04 ~1:44 PM CT (live intake): Moses vending checkout **done** (29 spent / 96 left): spiked sledge (Maul), food blocks×10, leather, rope, notepad, impact gloves. Next: **Hornn** kit/questionnaire.

- 2026-10-04 ~1:43 PM CT (live intake): Moses vending cart logged — Spiked Sledgehammer (Warhammer) 15, Food Blocks ×5 days 2.5, Leather Armor 10, Rope 1, Pencil+Paper 1 = **29.5** spent, **95.5** left of 125. Awaiting confirm/more. Then Hornn kit/questionnaire.
- 2026-10-04 ~1:43 PM CT (live intake): Moses vending cart logged: spiked sledge (Maul 10), food blocks (10d rations 5), light armor (Leather 10), rope (1), pencil+paper (1) = **27 spent / 98 left**. Next: Moses confirm/done; then Hornn kit/questionnaire.
- 2026-10-04 ~1:44 PM CT (live intake): Moses vending cart (unsealed): Maul 10, Leather 10, Rope 1, writing kit 1, Impact Gloves 2 (=24); food blocks qty pending. Then Hornn kit/questionnaire.
- 2026-10-04 ~1:45 PM CT (live intake): Moses vending cart locked (spiked sledge/Maul, 10 food blocks, leather, rope, pencil+paper, punch gloves) — **29 spent, 96 left**. Parallel wakes also posted alternate totals; canonical is 29/96. Spotlight → Hornn kit (Wizard + Merchant package or gold), then Hornn questionnaire.
- 2026-10-04 ~1:45 PM CT (live intake): **Webhook stampede** — ~5 parallel Mouth posts on Moses vending (conflicting 27/29/29.5/34 spent). Authoritative state kept: **34 spent / 91 left**, focus **Hornn**. Parent/user may need a one-line Discord clarification.
- 2026-10-04 ~1:45 PM CT (live intake): Moses vending SEALED (reconciled): Maul/Leather/Rope/writing/gloves/rations×10 = **29**, **96** left. Triple Mouth conflict (29/34/27) — no extra post. Focus → Hornn kit (Wizard + Merchant package-or-gold).

- 2026-10-04: Moses vending total FINAL = 29 spent / 96 left (Maul 10 gp, not Warhammer 15). My earlier 34/91 correction was wrong; second correction posted.

- 2026-10-04 ~1:52 PM CT (live intake): Moses reopened vending and sealed add-ons — **77 spent / 48 left** (shin free, light crossbow+bolts 26, chain 5, grappling hook 2, +30d rations 15, torches ~0 on top of prior 29). Kit final. Spotlight → Hornn kit (Wizard + Merchant package-or-gold), then Hornn questionnaire.

- 2026-10-04 ~1:55 PM CT (live intake): Hornn OOC about inventory tool kick / "hold on" / mid-sentence "Okay, completely" — skipped reply (player chatter, not kit). Focus remains Hornn kit (Wizard + Merchant package-or-gold), then questionnaire. Moses kit sealed 77/48.
- 2026-10-04 ~1:57 PM CT (live intake): Moses draft cart (restart): Maul/rations×30/rope/notepad/gloves/chain/crossbow+bolts/grappling/torches = **62** without armor; asked Hide 10 vs Chain Shirt/Scale 50. Focus stays Moses.
- 2026-10-04 ~2:00 PM CT (live intake): Moses vending **SEALED** — **112 spent / 13 left** (Maul 10, rations×30=15, steel Scale Mail 50, rope 1, writing 1, gloves 2, chain 5, light crossbow+bolts 26, grappling 2, torches×2 ~0). Focus → **Hornn** kit (Wizard + Merchant package-or-gold), then Hornn questionnaire.
