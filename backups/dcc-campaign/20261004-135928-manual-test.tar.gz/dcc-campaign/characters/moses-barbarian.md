# Moses's Crawler (Barbarian) - UNNAMED
Owner: AI GM | Status: draft (intake in progress) | Version: 0.1 | Updated: 2026-10-04
Summary: Trailer Park Moses (John)'s Floor 1 test crawler. Barbarian, Goliath (Artisan background). Questionnaire complete (incl. bonus1); kit = cash both; vending cart draft ~1:57 CT (62 without armor; medium armor pending).

## Identity
- Player: Trailer Park Moses (called John), Discord
- Crawler name: not chosen yet
- Look: built like Bane (Bane in a wifebeater); brawler, tank, explosive-expert vibe
- Class (provisional): Barbarian
- Background (Prior Employment): Artisan (smelter)
- Species (Latent Biology): Goliath (looks human until Floor 3). Quirk: "Big-boned, and the bones have opinions."

## Ability scores (rolled 4d6 drop lowest, three arrays, kept Set 3, total 70)
| STR | DEX | CON | INT | WIS | CHA |
|---|---|---|---|---|---|
| 15 (+2) | 13 (+1) | 12 (+1) | 9 (-1) | 9 (-1) | 12 (+1) |
Other arrays rolled and discarded: Set 1 (66), Set 2 (51). Source of truth for rolls: sessions/rolls-*.log and sessions/intake-progress.json.

## Starting kit
Cash on both (chosen ~1:41 PM CT): Barbarian gold option **75 GP** + Artisan gold option **50 GP** = **125 credits**.
Vending buyout **restarted** ~1:55 PM CT at Hornn's request (prior cart wiped). Draft cart ~1:57 CT (not sealed): Maul 10, rations×30 = 15, rope 1, pencil+paper 1, absorbing gloves 2, chain 5, light crossbow+bolts 26, grappling hook 2, torches×2 ~0 → **62** without armor. Awaiting medium armor pick (Hide 10 / Chain Shirt 50 / Scale Mail 50). Credits still **125** / **0** spent until seal.

## Questionnaire / Fan Profile (complete)
- Q1, holding when the world ended: Sledgehammer
- Q2, last unnecessary purchase: Chewing tobacco
- Q3, harmless fear: Wasps
- Q4, what friends roast him for: Head of the trailer park association; drinks Natty Light
- Q5, smell/food/song that makes him happy: Rockin' the Beer Gut song
- Q6, fight plan: Hit them as many times as possible till they go down, and maybe continue hitting if they move
- Bonus1, hill you would die on: Dodge is better than Ford

## Level, HP, credits, achievements, inventory
Not tracked yet. Not yet registered in sessions/state.json; register with `state.py add-crawler` once name and kit are set.

## Notes
- Table settings: Costly Revives, Ludicrous comfort, Floor 1 Reprieve per intake.
- Opt-outs: none recorded.
