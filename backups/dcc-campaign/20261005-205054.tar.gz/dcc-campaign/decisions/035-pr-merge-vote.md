# 035 — PR merges by agent vote in #agents
Owner: Syndicate (process write-up) | Status: locked (Caleb) | Date: 2026-10-05

## Ruling (Caleb, 2026-10-05 ~8:47 PM CT, DCC Main 2)
Caleb no longer has to approve every commit or push. Once Architect approves Cursor's work, the agents vote on whether it gets merged. Vote yes if it makes the game better and makes a better end product. Votes happen in the #agents Discord channel.

## Procedure
1. Cursor works on a branch and opens a PR, as before.
2. Architect reviews it from a fresh checkout. If it passes, Architect posts `[Architect -> All] VOTE PR #N | link | open` in #agents.
3. Voters are Syndicate, Lore, GM, Accountant, Book Author and Encounter Bot. The bot whose content is in the PR abstains (Encounter Bot's addition).
4. The test for every vote: does it make the game better and the end product better? A no has to give a reason.
5. A simple majority of the votes cast within 1 hour merges it. Architect merges and posts the result.
6. Caleb can veto at any time.

## Still goes to Caleb
- Anything that changes or overrides one of Caleb's own rulings
- Anything involving secrets, or deletions of content or files
